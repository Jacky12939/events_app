import React from 'react';
import { Navigate } from 'react-router-dom';
import { AuthStorage } from '../../features/Authentification/data/storage/auth.storage';

interface ProtectedRouteProps {
  children: React.ReactElement;
  allowedRoles?: string[]; // Liste optionnelle des rôles autorisés (ex: ['PARTICIPANT'])
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ 
  children, 
  allowedRoles 
}) => {
  // 1. Vérification globale de la session via le stockage dédié
  const isAuthenticated = AuthStorage.hasValidSession();

  if (!isAuthenticated) {
    // Redirection automatique vers la page de connexion si non connecté
    return <Navigate to="/auth" replace />;
  }

  // 2. Vérification optionnelle des droits et rôles applicatifs
  if (allowedRoles && allowedRoles.length > 0) {
    // Récupération sécurisée du rôle (Exemple via une méthode dédiée à rajouter dans ton AuthStorage)
    const userRole = localStorage.getItem('user_role') || 'PARTICIPANT';

    const isAuthorized = allowedRoles.includes(userRole);

    if (!isAuthorized) {
      // Redirection vers la page "Accès Interdit" si le rôle ne correspond pas
      return <Navigate to="/unauthorized" replace />;
    }
  }

  // Si tout est valide, on affiche le composant enfant (la page protégée)
  return children;
};