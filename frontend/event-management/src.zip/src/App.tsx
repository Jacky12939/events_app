import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';

// Importations de la Feature Landing
import { LandingPage } from './features/Landing/presentation/components/LandingPage';

// Importations de la Feature Authentification (Ajuste la casse selon tes dossiers)
import { AuthScreen } from './features/Authentification/presentation/components/AuthScreen';

// Importations de la Feature Participant (Espace Protégé)
import { ParticipantDashboard } from './features/participant/presentation/components/ParticipantDashboard';

// Importations Partagées (Guards & Pages d'erreur)
import { ProtectedRoute } from './shared/guards/ProtectedRoute';
import { UnauthorizedPage } from './shared/components/UnauthorizedPage';

export const App: React.FC = () => {
  return (
    <Router>
      <Routes>
        {/* ========================================================= */}
        {/* ROUTES PUBLIQUES                                          */}
        {/* ========================================================= */}
        <Route path="/" element={<LandingPage />} />
        
        {/* Connexion et inscription partagent le même composant AuthScreen dynamique */}
        <Route path="/login" element={<AuthScreen onAuthSuccess={() => window.location.href = '/participant/events'} />} />
        <Route path="/register" element={<AuthScreen onAuthSuccess={() => window.location.href = '/participant/events'} />} />
        
        <Route path="/unauthorized" element={<UnauthorizedPage />} />

        {/* ========================================================= */}
        {/* ROUTES PROTÉGÉES (Réservées uniquement aux Participants)  */}
        {/* ========================================================= */}
        <Route 
          path="/participant/events" 
          element={
            <ProtectedRoute allowedRoles={['PARTICIPANT']}>
              <ParticipantDashboard />
            </ProtectedRoute>
          } 
        />

        {/* Redirection automatique pour toutes les routes inconnues */}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Router>
  );
};

export default App;