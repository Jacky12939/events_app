import axios, {  type AxiosInstance } from 'axios';
import type { AuthRepository } from '../../domain/repositories/AuthRepository';
import type { LoginInput, RegisterInput } from '../../presentation/validator/authSchemas';
import type { AuthResponseDto } from '../dtos/AuthDto';
import type { UserSessionEntity } from '../../domain/entities/auth.';
import { AuthMapper } from '../mappers/AuthMapper';

export class AuthRepositoryImpl implements AuthRepository {
  private api: AxiosInstance;

  constructor() {
    this.api = axios.create({
      baseURL: import.meta.env.VITE_API_BASE_URL ,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  async login(credentials: LoginInput): Promise<UserSessionEntity> {
    // Emplacement pour l'appel API Axios de connexion
    const response = await this.api.post<AuthResponseDto>('/auth/login', {
      email: credentials.email,
      password: credentials.password,
    });
    
    // Stockage sécurisé du token
    localStorage.setItem('access_token', response.data.access_token);
    return AuthMapper.toSessionEntity(response.data);
  }

  async register(accountData: RegisterInput): Promise<UserSessionEntity> {
    // Emplacement pour l'appel API Axios d'inscription (Rôle PARTICIPANT forcé par défaut en backend/frontend)
    const response = await this.api.post<AuthResponseDto>('/auth/register', {
      firstName: accountData.firstName,
      email: accountData.email,
      password: accountData.password,
      role: 'PARTICIPANT', 
    });

    localStorage.setItem('access_token', response.data.access_token);
    return AuthMapper.toSessionEntity(response.data);
  }
}