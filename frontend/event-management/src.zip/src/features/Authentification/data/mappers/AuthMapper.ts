import type { UserSessionEntity } from "../../domain/entities/auth.";
import type { AuthResponseDto } from "../dtos/AuthDto";

export class AuthMapper {
  static toSessionEntity(dto: AuthResponseDto): UserSessionEntity {
    
    let userRole: "PARTICIPANT" | "ADMIN" | "ORGANIZER" = "PARTICIPANT";

    if (dto.user.role === "ADMIN" || dto.user.role === "ORGANIZER" || dto.user.role === "PARTICIPANT") {
      userRole = dto.user.role;
    }

    return {
      token: dto.access_token,
      user: {
        id: dto.user.id,
        firstName: dto.user.firstName,
        email: dto.user.email,
        role: userRole, 
      },
    };
  }
}