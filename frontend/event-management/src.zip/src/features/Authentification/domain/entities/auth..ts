export interface UserSessionEntity {
  token: string;
  user: {
    id: string;
    firstName: string;
    email: string;
    role: 'ADMIN' | 'ORGANIZER' | 'PARTICIPANT'; // Rôle par défaut à l'inscription
  };
}