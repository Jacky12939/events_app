import type { LoginInput, RegisterInput } from "../../presentation/validator/authSchemas";
import type { UserSessionEntity } from "../entities/auth.";

export interface AuthRepository {
  login(credentials: LoginInput): Promise<UserSessionEntity>;
  register(accountData: RegisterInput): Promise<UserSessionEntity>;
}