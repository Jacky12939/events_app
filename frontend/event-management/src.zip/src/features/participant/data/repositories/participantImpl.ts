import axios, { type AxiosInstance } from 'axios';
import type { ParticipantEventEntity, ParticipantProfileEntity } from '../../domain/entities/ParticipantEntities';
import type { ParticipantEventDto, ParticipantProfileDto } from '../dto/participant';
import { ParticipantMapper } from '../mappers/participant';
import type { ParticipantRepository } from '../../domain/repositories/participant';

export class ParticipantRepositoryImpl implements ParticipantRepository {
  private api: AxiosInstance;

  constructor() {
    this.api = axios.create({
      // CORRECTION : Remplacement de process.env par import.meta.env propre à Vite
      baseURL: import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api/v1',
      headers: { 'Content-Type': 'application/json' },
    });

    // Injection automatique du token API dans Axios
    this.api.interceptors.request.use((config) => {
      const token = localStorage.getItem('access_token');
      if (token && config.headers) {
        config.headers.Authorization = `Bearer ${token}`;
      }
      return config;
    });
  }

  async getAvailableEvents(): Promise<ParticipantEventEntity[]> {
    const response = await this.api.get<ParticipantEventDto[]>('/participant/events');
    return response.data.map(ParticipantMapper.toEventEntity);
  }

  async getEventDetails(eventId: string): Promise<ParticipantEventEntity> {
    const response = await this.api.get<ParticipantEventDto>(`/participant/events/${eventId}`);
    return ParticipantMapper.toEventEntity(response.data);
  }

  async registerToEvent(eventId: string): Promise<{ success: boolean; ticketNumber?: string }> {
    const response = await this.api.post<{ success: boolean; ticket_code?: string }>(`/participant/events/${eventId}/register`);
    return {
      success: response.data.success,
      ticketNumber: response.data.ticket_code,
    };
  }

  async getMyTickets(): Promise<ParticipantEventEntity[]> {
    const response = await this.api.get<ParticipantEventDto[]>('/participant/my-tickets');
    return response.data.map(ParticipantMapper.toEventEntity);
  }

  async getProfile(): Promise<ParticipantProfileEntity> {
    const response = await this.api.get<ParticipantProfileDto>('/participant/profile');
    return ParticipantMapper.toProfileEntity(response.data);
  }
}