import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  FiCalendar, FiSun, FiMoon, FiMenu, FiX, FiArrowRight, 
   FiShield, FiSliders, FiCheckCircle, FiSearch, FiMapPin 
} from 'react-icons/fi';

// Importation des composants Swiper React et des styles requis
import { Swiper, SwiperSlide } from 'swiper/react';
import { Autoplay, EffectFade, Pagination } from 'swiper/modules';
// import { FiQrCode } from 'react-qr-code'
import 'swiper/css';
import 'swiper/css/effect-fade';
import 'swiper/css/pagination';

export const LandingPage: React.FC = () => {
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('participant-theme') === 'dark');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('participant-theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('participant-theme', 'light');
    }
  }, [darkMode]);

  // Images du Slider de la Section Hero (Remplacer par vos propres URLs ou assets locaux)
  const heroSlides = [
    {
      image: 'https://images.unsplash.com/photo-1511578314322-379afb476865?auto=format&fit=crop&w=1200&q=80',
      title: 'Conférences Tech & Salons'
    },
    {
      image: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=1200&q=80',
      title: 'Concerts & Événements Culturels'
    },
    {
      image: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=1200&q=80',
      title: 'Galas & Soirées de Prestige'
    }
  ];

  const featuredEvents = [
    { id: 1, title: 'Tech Confluence 2026', date: '15 Juillet 2026', location: 'Yaoundé, Palais des Congrès', category: 'Technologie', price: 'Gratuit' },
    { id: 2, title: 'Festival Afro-Beat Heritage', date: '22 Août 2026', location: 'Bandjoun, Place Royale', category: 'Culture', price: '5 000 FCFA' },
    { id: 3, title: 'Gala Prestige & Networking', date: '05 Septembre 2026', location: 'Douala, Bonanjo', category: 'Professionnel', price: '10 000 FCFA' },
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 transition-colors duration-200 font-sans antialiased">
      
      {/* 1. NAVBAR */}
      <nav className="sticky top-0 z-50 bg-white/80 dark:bg-slate-900/80 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            <div className="flex items-center gap-2 text-blue-600 dark:text-blue-400 font-black text-2xl tracking-tight">
              <FiCalendar className="w-8 h-8" />
              <span>EventHub</span>
            </div>

            <div className="hidden md:flex items-center space-x-8 font-semibold text-base text-slate-600 dark:text-slate-300">
              <a href="#discover" className="hover:text-blue-600 dark:hover:text-blue-400 transition">Découvrir</a>
              <a href="#features" className="hover:text-blue-600 dark:hover:text-blue-400 transition">Fonctionnalités</a>
              <a href="#about" className="hover:text-blue-600 dark:hover:text-blue-400 transition">À propos</a>
            </div>

            <div className="hidden md:flex items-center space-x-4">
              <button 
                onClick={() => setDarkMode(!darkMode)}
                className="p-2.5 rounded-xl text-slate-600 dark:text-amber-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                {darkMode ? <FiSun size={22} /> : <FiMoon size={22} />}
              </button>
              <Link to="/login" className="px-5 py-2.5 text-base font-bold text-slate-700 dark:text-slate-200 hover:text-blue-600 dark:hover:text-blue-400 transition">
                Connexion
              </Link>
              <Link to="/register" className="px-6 py-2.5 text-base font-extrabold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition shadow-md">
                S'inscrire
              </Link>
            </div>

            <div className="flex items-center space-x-3 md:hidden">
              <button onClick={() => setDarkMode(!darkMode)} className="p-2 text-slate-600 dark:text-amber-400">
                {darkMode ? <FiSun size={20} /> : <FiMoon size={20} />}
              </button>
              <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="p-2 text-slate-600 dark:text-slate-300">
                {mobileMenuOpen ? <FiX size={26} /> : <FiMenu size={26} />}
              </button>
            </div>
          </div>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 pt-2 pb-6 space-y-4 shadow-lg">
            <div className="flex flex-col space-y-3 font-bold text-lg text-slate-600 dark:text-slate-300">
              <a href="#discover" onClick={() => setMobileMenuOpen(false)} className="py-2 hover:text-blue-600">Découvrir</a>
              <a href="#features" onClick={() => setMobileMenuOpen(false)} className="py-2 hover:text-blue-600">Fonctionnalités</a>
              <a href="#about" onClick={() => setMobileMenuOpen(false)} className="py-2 hover:text-blue-600">À propos</a>
            </div>
            <div className="border-t border-slate-100 dark:border-slate-800 pt-4 flex flex-col space-y-3">
              <Link to="/login" onClick={() => setMobileMenuOpen(false)} className="w-full text-center py-3 font-bold text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-800 rounded-xl">
                Connexion
              </Link>
              <Link to="/register" onClick={() => setMobileMenuOpen(false)} className="w-full text-center py-3 font-black text-white bg-blue-600 rounded-xl">
                S'inscrire
              </Link>
            </div>
          </div>
        )}
      </nav>

      {/* 2. SECTION HERO AVEC SLIDER D'IMAGES SPLIT-SCREEN */}
      <header className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 pb-20 lg:pt-14 lg:pb-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Bloc Texte (Gauche sur Desktop) */}
          <div className="lg:col-span-6 space-y-6 text-center lg:text-left flex flex-col items-center lg:items-start">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-blue-50 dark:bg-blue-950/50 border border-blue-200/50 dark:border-blue-900 text-blue-600 dark:text-blue-400 text-sm sm:text-base font-bold uppercase tracking-wide">
              <FiCheckCircle /> Solution d'Événementiel MVP v1.0
            </div>
            
            <h1 className="text-4xl sm:text-6xl font-black text-slate-900 dark:text-white tracking-tight leading-tight">
              Trouvez des événements. Obtenez vos <span className="text-blue-600 dark:text-blue-400">Tickets QR</span>.
            </h1>
            
            <p className="text-lg sm:text-xl text-slate-500 dark:text-slate-400 font-medium max-w-xl">
              Rejoignez l'espace participant. Explorez des salons professionnels, des festivals et des conférences exclusives, puis gérez vos accès simplement.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 w-full sm:w-auto pt-2">
              <Link to="/register" className="w-full sm:w-auto px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white font-extrabold text-lg rounded-xl transition shadow-lg flex items-center justify-center gap-2 group cursor-pointer">
                Créer un compte <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
              </Link>
              <a href="#discover" className="w-full sm:w-auto px-8 py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-lg rounded-xl transition flex items-center justify-center">
                Voir le catalogue
              </a>
            </div>
          </div>

          {/* Bloc Slider Innovant (Droite sur Desktop) */}
          <div className="lg:col-span-6 w-full h-[320px] sm:h-[450px] rounded-3xl overflow-hidden shadow-2xl border border-slate-200 dark:border-slate-800 relative group">
            <Swiper
              modules={[Autoplay, EffectFade, Pagination]}
              effect={'fade'}
              autoplay={{ delay: 4000, disableOnInteraction: false }}
              pagination={{ clickable: true, dynamicBullets: true }}
              className="w-full h-full"
            >
              {heroSlides.map((slide, index) => (
                <SwiperSlide key={index} className="relative w-full h-full">
                  {/* Image de fond */}
                  <img 
                    src={slide.image} 
                    alt={slide.title} 
                    className="w-full h-full object-cover transform scale-100 group-hover:scale-105 transition-transform duration-700 ease-out" 
                  />
                  {/* Overlay dégradé sombre pour faire ressortir le texte */}
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />
                  
                  {/* Titre contextuel sur l'image */}
                  <div className="absolute bottom-6 left-6 right-6 text-left">
                    <p className="text-white text-xl sm:text-2xl font-black tracking-tight drop-shadow-md">
                      {slide.title}
                    </p>
                  </div>
                </SwiperSlide>
              ))}
            </Swiper>
          </div>

        </div>
      </header>

      {/* 3. CATALOGUE */}
      <section id="discover" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 border-t border-slate-200/60 dark:border-slate-900">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 space-y-4 md:space-y-0">
          <div className="space-y-2">
            <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Événements à l'affiche</h2>
            <p className="text-base sm:text-lg text-slate-500 dark:text-slate-400 font-medium">Réservez dès maintenant vos places pour les prochains grands rendez-vous.</p>
          </div>
          <div className="flex items-center gap-3 bg-white dark:bg-slate-900 px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 w-full md:w-80">
            <FiSearch className="text-slate-400 shrink-0" />
            <input type="text" placeholder="Rechercher une ville, un thème..." className="bg-transparent text-sm w-full focus:outline-none font-medium" disabled />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredEvents.map((event) => (
            <div key={event.id} className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200/80 dark:border-slate-800 overflow-hidden shadow-sm hover:shadow-md transition">
              <div className="p-6 space-y-4">
                <span className="inline-block px-3 py-1 text-xs font-bold uppercase tracking-wider rounded-md bg-blue-50 dark:bg-blue-950 text-blue-600 dark:text-blue-400">
                  {event.category}
                </span>
                <h3 className="text-xl font-bold text-slate-900 dark:text-white line-clamp-1">{event.title}</h3>
                
                <div className="space-y-2 text-base text-slate-500 dark:text-slate-400 font-medium">
                  <div className="flex items-center gap-2">
                    <FiCalendar className="text-slate-400" /> <span>{event.date}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FiMapPin className="text-slate-400" /> <span className="line-clamp-1">{event.location}</span>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  <span className="text-lg font-black text-slate-900 dark:text-white">{event.price}</span>
                  <Link to="/login" className="text-sm font-bold text-blue-600 dark:text-blue-400 flex items-center gap-1 hover:underline">
                    Réservez <FiArrowRight />
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. FONCTIONNALITÉS */}
      <section id="features" className="bg-slate-100 dark:bg-slate-900/40 py-20 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
            <h2 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white tracking-tight">
              Une expérience fluide et sécurisée
            </h2>
            <p className="text-lg text-slate-500 dark:text-slate-400 font-medium">
              Tout est pensé pour simplifier l'accès, le suivi et la validation de vos billets d'entrée.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200/60 dark:border-slate-800 space-y-4">
              <div className="w-12 h-12 rounded-xl bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 flex items-center justify-center text-2xl">
                {/* <FiQrCode /> */}
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Tickets QR Sécurisés</h3>
              <p className="text-base text-slate-500 dark:text-slate-400 font-medium leading-relaxed">
                Dès confirmation, votre ticket unique contenant un code QR est généré. Présentez-le simplement à l'entrée sur votre smartphone.
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200/60 dark:border-slate-800 space-y-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center text-2xl">
                <FiShield />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Contrôle Anti-Fraude</h3>
              <p className="text-base text-slate-500 dark:text-slate-400 font-medium leading-relaxed">
                Chaque ticket ne peut être scanné qu'une seule fois par l'application de l'organisateur. Fini les risques de doublons.
              </p>
            </div>

            <div className="bg-white dark:bg-slate-900 p-8 rounded-2xl border border-slate-200/60 dark:border-slate-800 space-y-4">
              <div className="w-12 h-12 rounded-xl bg-purple-100 dark:bg-purple-950 text-purple-600 dark:text-purple-400 flex items-center justify-center text-2xl">
                <FiSliders />
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white">Historique Centralisé</h3>
              <p className="text-base text-slate-500 dark:text-slate-400 font-medium leading-relaxed">
                Suivez toutes vos invitations passées et à venir depuis votre tableau de bord participant, disponible en ligne et hors ligne.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 5. FOOTER */}
      <footer id="about" className="bg-white dark:bg-slate-950 border-t border-slate-200/80 dark:border-slate-900 py-12 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center space-y-4 sm:space-y-0 text-base font-medium text-slate-500 dark:text-slate-400">
          <div className="flex items-center gap-2 font-bold text-slate-900 dark:text-white text-lg">
            <FiCalendar className="text-blue-600 dark:text-blue-400" /> EventHub
          </div>
          <p>&copy; 2026 EventHub SGE. Tous droits réservés.</p>
          <div className="flex space-x-6">
            <a href="#" className="hover:text-blue-600 transition">Mentions Légales</a>
            <a href="#" className="hover:text-blue-600 transition">Support</a>
          </div>
        </div>
      </footer>

    </div>
  );
};

export default LandingPage;