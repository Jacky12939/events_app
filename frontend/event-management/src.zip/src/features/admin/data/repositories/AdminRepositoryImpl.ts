
import  type{ BaseUser, AdminEventSummary, AdminStats, AdminProfile } from '../../domain/entities/AdminEntities';
import type { AdminRepository } from '../../domain/repositories/AdminRepository';
import type { AdminEventDTO, UserDTO } from '../dtos/AdminDTO';

import { AdminMapper } from '../mappers/AdminMapper';

let mockUsers: UserDTO[] = [
  { usr_id: 'u1', usr_name: 'Organisateur Demo', usr_email: 'organizer@example.com', usr_role_code: 'organisateur', usr_created_at: '15 janvier 2024' },
  { usr_id: 'u2', usr_name: 'Jean Martin', usr_email: 'jean.martin@example.com', usr_role_code: 'organisateur', usr_created_at: '10 mars 2024' },
  { usr_id: 'u3', usr_name: 'Participant Demo', usr_email: 'participant@example.com', usr_role_code: 'participant', usr_created_at: '01 février 2024' },
  { usr_id: 'u4', usr_name: 'Marie Dupont', usr_email: 'marie.dupont@example.com', usr_role_code: 'participant', usr_created_at: '22 février 2024' },
  { usr_id: 'u5', usr_name: 'Sophie Bernard', usr_email: 'sophie.bernard@example.com', usr_role_code: 'participant', usr_created_at: '05 avril 2024' },
];

const mockEvents: AdminEventDTO[] = [
  { evt_id: 'e1', evt_title: 'Conférence Tech 2024', evt_date: '15 juin 2024', evt_slots_taken: 45, evt_slots_max: 200, evt_cat: 'Conférence', evt_status: 'publie' },
  { evt_id: 'e2', evt_title: 'Atelier Design Thinking', evt_date: '20 juil. 2024', evt_slots_taken: 12, evt_slots_max: 30, evt_cat: 'Atelier', evt_status: 'publie' },
  { evt_id: 'e3', evt_title: 'Formation React Avancé', evt_date: '10 août 2024', evt_slots_taken: 18, evt_slots_max: 25, evt_cat: 'Formation', evt_status: 'publie' },
  { evt_id: 'e4', evt_title: 'Networking Digital Nomads', evt_date: '05 sept. 2024', evt_slots_taken: 32, evt_slots_max: 50, evt_cat: 'Networking', evt_status: 'publie' },
  { evt_id: 'e5', evt_title: 'Webinaire IA et Marketing', evt_date: '25 juin 2024', evt_slots_taken: 234, evt_slots_max: 500, evt_cat: 'Webinaire', evt_status: 'publie' },
  { evt_id: 'e6', evt_title: 'Concert Jazz Manouche', evt_date: '12 juil. 2024', evt_slots_taken: 89, evt_slots_max: 150, evt_cat: 'Concert', evt_status: 'publie' },
];

export class AdminRepositoryImpl implements AdminRepository {
  async getStats(): Promise<AdminStats> {
    return {
      totalEvents: 9,
      publishedEvents: 8,
      totalRegistrations: 953,
      organizerCount: mockUsers.filter(u => u.usr_role_code === 'organisateur').length,
      participantCount: mockUsers.filter(u => u.usr_role_code === 'participant').length,
    };
  }

  async getUsers(): Promise<BaseUser[]> {
    return mockUsers.map(AdminMapper.toUserDomain);
  }

  async getLatestEvents(): Promise<AdminEventSummary[]> {
    return mockEvents.map(AdminMapper.toEventDomain);
  }

  async getProfile(): Promise<AdminProfile> {
    return { name: 'Administrateur', email: 'admin@example.com', role: 'Administrateur', memberSince: '01 janvier 2024' };
  }

  async getUserCreatedEvents(): Promise<AdminEventSummary[]> {
    return mockEvents.map(AdminMapper.toEventDomain);
  }

  async getUserRegistrations() {
    return [
      { eventTitle: 'Conférence Tech 2024', date: '15 juin 2024', registrationDate: '15/05/2024', ticketNumber: 'TKT-001-2024', category: 'Conférence' }
    ];
  }

  async createOrganizer(name: string, email: string): Promise<BaseUser> {
    const newUser: UserDTO = {
      usr_id: 'u_' + Math.random().toString(36).substr(2, 9),
      usr_name: name,
      usr_email: email,
      usr_role_code: 'organisateur',
      usr_created_at: new Date().toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' })
    };
    mockUsers.push(newUser);
    return AdminMapper.toUserDomain(newUser);
  }

  async deleteUser(userId: string): Promise<void> {
    mockUsers = mockUsers.filter(u => u.usr_id !== userId);
  }
}