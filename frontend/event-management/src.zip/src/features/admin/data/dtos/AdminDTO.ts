export interface UserDTO {
  usr_id: string;
  usr_name: string;
  usr_email: string;
  usr_role_code: 'organisateur' | 'participant';
  usr_created_at: string;
}

export interface AdminEventDTO {
  evt_id: string;
  evt_title: string;
  evt_date: string;
  evt_slots_taken: number;
  evt_slots_max: number;
  evt_cat: string;
  evt_status: 'publie' | 'brouillon';
}