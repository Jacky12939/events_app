import type { BaseUser, AdminEventSummary } from '../../domain/entities/AdminEntities';
import type { AdminEventDTO, UserDTO } from '../dtos/AdminDTO';


export class AdminMapper {
  static toUserDomain(dto: UserDTO): BaseUser {
    return {
      id: dto.usr_id,
      name: dto.usr_name,
      email: dto.usr_email,
      role: dto.usr_role_code,
      registrationDate: dto.usr_created_at,
    };
  }

  static toEventDomain(dto: AdminEventDTO): AdminEventSummary {
    return {
      id: dto.evt_id,
      title: dto.evt_title,
      date: dto.evt_date,
      registeredCount: dto.evt_slots_taken,
      capacity: dto.evt_slots_max,
      category: dto.evt_cat,
      status: dto.evt_status === 'publie' ? 'publé' : 'brouillon',
    };
  }
}